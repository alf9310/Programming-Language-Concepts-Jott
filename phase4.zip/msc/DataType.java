package msc;

public enum DataType {
    BOOLEAN,
    STRING,
    INTEGER,
    DOUBLE, 
    VOID,
    ANY
}
